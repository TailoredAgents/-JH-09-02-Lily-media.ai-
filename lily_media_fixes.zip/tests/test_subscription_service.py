"""
Unit tests for the subscription service.

These tests provide a starting point for verifying that the
``SubscriptionService`` behaves correctly.  They should be expanded with
integration tests that exercise database interactions and tier enforcement.
Run these tests with ``pytest``.
"""

import pytest

from backend.services.subscription_service import SubscriptionService, SubscriptionTier


def test_normalize_tier_basic():
    service = SubscriptionService(db=None)
    assert service.normalize_tier("base") == SubscriptionTier.BASIC
    assert service.normalize_tier("basic") == SubscriptionTier.BASIC
    assert service.normalize_tier("starter") == SubscriptionTier.BASIC


def test_normalize_tier_premium():
    service = SubscriptionService(db=None)
    assert service.normalize_tier("pro") == SubscriptionTier.PREMIUM
    assert service.normalize_tier("premium") == SubscriptionTier.PREMIUM
    assert service.normalize_tier("professional") == SubscriptionTier.PREMIUM


def test_normalize_tier_enterprise():
    service = SubscriptionService(db=None)
    assert service.normalize_tier("enterprise") == SubscriptionTier.ENTERPRISE


def test_feature_sets():
    # Verify that higher tiers include all features of lower tiers
    service = SubscriptionService(db=None)
    basic = service.get_tier_features(user_id=0)
    premium = service.get_tier_features(user_id=0, organization_id=None)
    enterprise = service.get_tier_features(user_id=0, organization_id=None)
    assert basic <= premium <= enterprise
