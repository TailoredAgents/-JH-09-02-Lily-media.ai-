"""
Simplified environment variable validator for production security.

This module provides a lightweight validation routine for critical
environment variables required to run the AI social media platform in
production.  It is intentionally minimal compared to the upstream
`env_validator.py` but captures the most important checks (secret key,
database URL and OpenAI API key).  It also exposes a ``validate_on_startup``
function that can be called at application startup to enforce these
checks.  If validation fails, the function raises a ``RuntimeError``
describing the missing or insecure configuration.
"""

import os
import logging
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


def validate_environment() -> Dict[str, Any]:
    """
    Validate critical environment variables required for production.

    Returns a dictionary containing the validation status, any errors or
    warnings, and the redacted values of validated variables.
    """
    results: Dict[str, Any] = {
        "validation_passed": True,
        "errors": [],
        "warnings": [],
        "validated_vars": {},
    }
    # Required variables with basic security requirements
    required_vars: Dict[str, Dict[str, Any]] = {
        "SECRET_KEY": {
            "description": "JWT and session encryption key",
            "min_length": 32,
            "secure": True,
        },
        "DATABASE_URL": {
            "description": "Database connection URL",
            "min_length": 10,
            "secure": False,
        },
        "OPENAI_API_KEY": {
            "description": "OpenAI API key for content generation",
            "min_length": 20,
            "secure": True,
        },
    }
    for var_name, config in required_vars.items():
        value = os.getenv(var_name)
        if not value:
            results["validation_passed"] = False
            results["errors"].append(
                f"Missing required environment variable: {var_name} ({config['description']})"
            )
            continue
        if len(value) < config.get("min_length", 1):
            results["validation_passed"] = False
            results["errors"].append(
                f"Environment variable {var_name} is too short (minimum {config['min_length']} characters)"
            )
            continue
        # Redact secure values
        if config.get("secure"):
            results["validated_vars"][var_name] = f"***{value[-4:]}"
        else:
            results["validated_vars"][var_name] = value
    return results


def validate_on_startup() -> None:
    """
    Run environment validation and raise an exception if critical variables are missing or insecure.

    This function should be called at application startup.  If validation fails,
    a ``RuntimeError`` is raised with a summary of all validation errors.  If
    validation passes, a debug log is emitted summarizing validated variables.
    """
    results = validate_environment()
    if results["validation_passed"]:
        # Log the validated variables (redacted) for diagnostics
        for var, val in results["validated_vars"].items():
            logger.debug(f"Environment variable {var} validated: {val}")
        return
    # Construct an error message listing all validation failures
    error_messages: List[str] = [str(err) for err in results["errors"]]
    message = "; ".join(error_messages)
    logger.error(f"Environment validation failed: {message}")
    raise RuntimeError(message)