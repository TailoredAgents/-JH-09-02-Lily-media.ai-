"""
Stripe payment and subscription API.

This module defines endpoints to create a checkout session and handle
webhooks from Stripe.  Because the ``stripe`` Python package is not
available in this environment, the implementation simulates the behaviour
of Stripe by returning dummy session IDs and invoking the subscription
service to update tiers directly.  In a real deployment you would
install ``stripe`` via pip and use ``stripe.checkout.Session.create`` and
``stripe.Webhook.construct_event`` to handle the webhook securely.
"""

from typing import Dict, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

from backend.db.database import get_db
from backend.db.models import User
from backend.auth.dependencies import get_current_active_user
from backend.services.subscription_service import SubscriptionTier, get_subscription_service

router = APIRouter(prefix="/api/stripe", tags=["stripe"])


class CheckoutRequest(BaseModel):
    """Request body for creating a checkout session."""
    plan: SubscriptionTier


@router.post("/create-checkout-session")
async def create_checkout_session(
    request: CheckoutRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
) -> Dict[str, str]:
    """
    Create a checkout session for upgrading a user's subscription.

    In this simplified implementation we simulate the creation of a Stripe
    checkout session and immediately upgrade the user.  In production
    environments you would use the Stripe API to create a session and
    redirect the client to the returned URL; the webhook handler would
    then perform the upgrade once payment succeeds.
    """
    # Validate requested plan against current tier
    subscription_service = get_subscription_service(db)
    current_tier = subscription_service.get_user_tier(current_user.id)
    desired_tier = request.plan
    if SubscriptionTier(desired_tier) == current_tier:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="You are already subscribed to this tier",
        )

    # Simulate session creation
    dummy_session_id = f"cs_test_{current_user.id}_{desired_tier.value}"
    dummy_checkout_url = f"https://example.com/checkout/{dummy_session_id}"

    # Immediately perform upgrade for the sake of this demo
    upgraded = subscription_service.upgrade_user_tier(current_user.id, desired_tier)
    if not upgraded:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to upgrade subscription tier",
        )

    # Normally you would return the session ID and allow the frontend to redirect
    # to Stripe; here we return a dummy URL to illustrate the expected payload.
    return {
        "session_id": dummy_session_id,
        "checkout_url": dummy_checkout_url,
        "message": f"User upgraded to {desired_tier.value}",
    }


class StripeWebhookEvent(BaseModel):
    """Minimal representation of a Stripe webhook event for testing."""
    type: str
    data: Dict[str, Dict[str, str]]


@router.post("/webhook", status_code=status.HTTP_200_OK)
async def stripe_webhook(
    payload: StripeWebhookEvent,
    db: Session = Depends(get_db),
) -> Dict[str, str]:
    """
    Handle Stripe webhook events.

    In a production system this endpoint would verify the Stripe signature
    header using your webhook signing secret.  Here we parse a minimal event
    payload and upgrade the user when a checkout session completes.
    """
    event_type = payload.type
    # Example payload structure:
    # {
    #   "type": "checkout.session.completed",
    #   "data": {"object": {"client_reference_id": "user_id", "metadata": {"plan": "premium"}}}
    # }
    try:
        if event_type == "checkout.session.completed":
            session = payload.data.get("object", {})
            user_id = int(session.get("client_reference_id"))
            plan_str = session.get("metadata", {}).get("plan", "basic")
            desired_tier = SubscriptionTier(plan_str)
            subscription_service = get_subscription_service(db)
            upgraded = subscription_service.upgrade_user_tier(user_id, desired_tier)
            if upgraded:
                return {"status": "success", "message": f"User {user_id} upgraded to {plan_str}"}
            return {"status": "failure", "message": "Failed to upgrade user"}
        # For all other events we simply acknowledge
        return {"status": "ignored", "message": f"Unhandled event {event_type}"}
    except Exception as exc:
        # Log the exception and return a generic response
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))