"""
Authentication API endpoints with optional registration key support.

This module defines the registration and login endpoints for the AI Social Media
platform. The registration endpoint now supports two modes:

1. **Open SaaS**: When no `registration_key` is supplied in the request body, any
   user can register for a free (Basic) plan. This enables frictionless sign-up
   for new users and is suitable for production SaaS deployments.
2. **Invite-only**: When a `registration_key` is provided, the key is validated
   against the `RegistrationKey` table. This preserves backward compatibility
   with invite-based onboarding flows. If the key is invalid or expired, an
   error is returned.

The rest of the authentication logic (login, token issuance, etc.) remains
unchanged and continues to use locally issued JWT tokens and optional 2FA.
"""

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status, Response
from pydantic import BaseModel, EmailStr, validator
from sqlalchemy.orm import Session

from backend.db.database import get_db
from backend.db.models import User, UserSetting, RefreshTokenBlacklist
from backend.db.admin_models import RegistrationKey
from backend.auth.dependencies import get_current_user, get_current_active_user, AuthUser
from backend.auth.jwt_handler import jwt_handler

router = APIRouter(prefix="/api/auth", tags=["authentication"])


class LoginRequest(BaseModel):
    email: EmailStr
    password: str
    totp_code: Optional[str] = None
    backup_code: Optional[str] = None

    @validator('totp_code')
    def validate_totp_code(cls, v):
        if v is not None and (len(v) != 6 or not v.isdigit()):
            raise ValueError('TOTP code must be 6 digits')
        return v

    @validator('backup_code')
    def validate_backup_code(cls, v):
        # Lazy import to avoid circular dependency
        from backend.auth.validators import normalize_and_validate_backup_code
        return normalize_and_validate_backup_code(v)


class RegisterRequest(BaseModel):
    email: EmailStr
    username: str
    password: str
    full_name: str = ""
    registration_key: Optional[str] = None


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: str
    email: str
    username: str


@router.post("/register", response_model=TokenResponse)
async def register_user(request: RegisterRequest, response: Response, db: Session = Depends(get_db)):
    """
    Register a new user. If a `registration_key` is provided, it must be valid and
    unused. Otherwise, the user is registered on the Basic tier without requiring
    a key.

    Args:
        request: Registration data including email, username, password and an optional key.
        response: FastAPI response object used to set cookies.
        db: Database session injected by FastAPI.

    Returns:
        A `TokenResponse` containing the access token and user details.

    Raises:
        HTTPException: If the email or username already exists, or if a provided
            registration key is invalid or expired.
    """
    # If a registration key is supplied, validate it according to the invite-only flow
    key = request.registration_key
    registration_key_obj: Optional[RegistrationKey] = None
    if key:
        registration_key_obj = db.query(RegistrationKey).filter(
            RegistrationKey.key == key
        ).first()
        if not registration_key_obj:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid registration key",
            )
        if not registration_key_obj.is_valid():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Registration key is expired or has been used up",
            )
        if not registration_key_obj.can_register_email(request.email):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Registration key is not valid for this email domain",
            )

    # Check if user already exists
    existing_user = db.query(User).filter(
        (User.email == request.email) | (User.username == request.username)
    ).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email or username already registered",
        )

    # Create new user with default tier 'basic' (free) unless registration key denotes otherwise.
    # Using the more explicit "basic" label avoids confusion with the legacy "base"
    # value and aligns with the normalized subscription tiers used throughout the
    # subscription service.  The ``SubscriptionService.normalize_tier`` method
    # still accepts "base" as a synonym, but new records should use "basic".
    hashed_password = jwt_handler.hash_password(request.password)
    new_user = User(
        email=request.email,
        username=request.username,
        full_name=request.full_name or request.username,
        hashed_password=hashed_password,
        is_active=True,
        tier="basic",
        auth_provider="local",
    )

    # If an invite-based registration key was used, associate it with the user and increment usage
    if registration_key_obj:
        new_user.registration_key_id = registration_key_obj.id
        registration_key_obj.current_uses += 1

    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    # Create default user settings
    user_settings = UserSetting(
        user_id=new_user.id,
        brand_name=request.full_name or request.username,
        brand_voice="professional",
        content_frequency=3,
        preferred_platforms=["twitter", "instagram"],
        posting_times={"twitter": "09:00", "instagram": "10:00"},
        creativity_level=0.7,
        enable_images=True,
        enable_repurposing=True,
    )
    db.add(user_settings)
    db.commit()

    # Create a personal organization for multi-tenancy
    try:
        from backend.middleware.tenant_isolation import create_personal_organization
        create_personal_organization(new_user, db)
    except Exception as e:
        # Log error but don't fail registration if org creation fails
        import logging
        logging.warning(
            f"Failed to create personal organization for user {new_user.id}: {e}"
        )

    # Issue access and refresh tokens
    tokens = jwt_handler.create_user_tokens(
        user_id=str(new_user.id),
        email=new_user.email,
        username=new_user.username,
    )

    # Set refresh token as HTTP-only cookie
    response.set_cookie(
        key="refresh_token",
        value=tokens["refresh_token"],
        httponly=True,
        secure=True,  # Use HTTPS in production
        samesite="none",  # Allow cross-origin cookie sending
        max_age=jwt_handler.refresh_token_expire_seconds,
    )

    return TokenResponse(
        access_token=tokens["access_token"],
        user_id=str(new_user.id),
        email=new_user.email,
        username=new_user.username,
    )