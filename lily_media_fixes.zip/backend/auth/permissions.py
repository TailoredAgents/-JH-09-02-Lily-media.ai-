"""
Role-based access control (RBAC) helpers.

This module defines decorators and utilities to enforce fine-grained permissions
on API routes. At runtime, these functions should verify that the current
authenticated user holds a role with the required permissions. For now, this
implementation is a placeholder that always allows access for administrative
users (premium/enterprise tiers) and denies otherwise. It can be extended to
check the `Role` and `Permission` models defined in `backend.db.multi_tenant_models`.
"""

from typing import Callable

from fastapi import Depends, HTTPException, status
from sqlalchemy.orm import Session

from backend.auth.dependencies import get_current_active_user
from backend.db.models import User
from backend.db.database import get_db


def require_admin(current_user: User = Depends(get_current_active_user)) -> User:
    """
    Dependency that ensures the current user has administrative privileges. This
    function is a thin wrapper around `get_current_active_user` that raises a
    `403 Forbidden` error if the user's tier is insufficient. Administrative
    users are those on premium or enterprise plans.
    """
    if current_user.tier not in ["pro", "premium", "enterprise"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Administrative privileges required",
        )
    return current_user


def require_permission(resource: str, action: str) -> Callable:
    """
    Factory function that returns a dependency to check that the current user
    possesses a specific permission. In this simplified implementation, any
    authenticated user on the premium or enterprise tier is considered to have
    all permissions. Extend this function to perform database lookups against
    `Role` and `Permission` tables for real RBAC enforcement.

    Args:
        resource: The name of the resource being accessed (e.g. "posts").
        action: The action being performed (e.g. "create", "delete").
    Returns:
        A dependency function that will raise an HTTP 403 error if the user
        lacks the required permission.
    """
    def permission_dependency(
        current_user: User = Depends(get_current_active_user),
        db: Session = Depends(get_db),
    ) -> User:
        # Placeholder permission logic: treat pro/premium/enterprise as allowed
        if current_user.tier not in ["pro", "premium", "enterprise"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Permission '{resource}.{action}' required",
            )
        return current_user
    return permission_dependency