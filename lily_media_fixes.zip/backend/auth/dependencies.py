"""
Authentication dependencies for FastAPI routes

This module defines helper functions and classes to retrieve the currently authenticated user
using locally issued JWT tokens. Legacy Auth0 support has been removed to simplify the
authentication surface and eliminate unused code paths. All authentication now relies on
the `backend.auth.jwt_handler` for token verification.
"""

from typing import Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session

from backend.db.database import get_db
from backend.db.models import User
from backend.auth.jwt_handler import JWTHandler

# Security scheme used by FastAPI to extract the Authorization header
security = HTTPBearer()

# Instantiate the JWT handler once for reuse
jwt_handler = JWTHandler()


class AuthUser:
    """Authenticated user model returned by authentication dependencies."""

    def __init__(self, user_id: str, email: str, username: str, auth_method: str = 'local') -> None:
        self.user_id = user_id
        self.email = email
        self.username = username
        self.auth_method = auth_method


async def get_token(credentials: HTTPAuthorizationCredentials = Depends(security)) -> str:
    """
    Extract a JWT from the Authorization header.

    Raises:
        HTTPException: If no credentials are provided or the scheme is incorrect.

    Returns:
        The raw JWT string.
    """
    if not credentials or not credentials.credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication token required",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return credentials.credentials


async def get_current_user(
    db: Session = Depends(get_db),
    token: str = Depends(get_token),
) -> AuthUser:
    """
    Retrieve the currently authenticated user from the provided JWT.

    The token is verified using the local JWT handler. If verification fails, an
    HTTP 401 error is returned. Upon success, an `AuthUser` instance is returned
    containing the user's ID, email and username. The database is not queried here; it
    simply extracts the identity from the token. Use `get_current_active_user` to
    enforce that the user exists and is active.
    """
    try:
        payload = jwt_handler.verify_token(token)
        user_id = payload.get("sub")
        email = payload.get("email")
        username = payload.get("username")
        if not (user_id and email and username):
            raise ValueError("Missing required claims in token")
        return AuthUser(
            user_id=user_id,
            email=email,
            username=username,
            auth_method="local",
        )
    except Exception:
        # Re-raise as HTTP 401 with WWW-Authenticate header for clients
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication token",
            headers={"WWW-Authenticate": "Bearer"},
        )


def get_current_active_user(
    current_user: AuthUser = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> User:
    """
    Fetch the full `User` record for the currently authenticated user and ensure
    the account is active.

    Args:
        current_user: The AuthUser extracted from the JWT token.
        db: A SQLAlchemy session.

    Raises:
        HTTPException: If the user does not exist or is inactive.

    Returns:
        The corresponding `User` ORM instance.
    """
    user = db.query(User).filter_by(email=current_user.email).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found in database",
        )
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is inactive",
        )
    return user


from fastapi import Request
from backend.middleware.tenant_isolation import get_tenant_context
from backend.auth.permissions import PermissionChecker

def get_admin_user(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
    request: Request = None,
) -> User:
    """
    Require that the current user has administrative privileges.

    Administrative privileges can come from several sources:
    * The user is marked as a superuser.
    * The user is on a paid tier (``pro``, ``premium`` or ``enterprise``).
    * The user holds an organization-level role with elevated permissions
      (``org_owner`` or ``admin``) within the current tenant context.

    Args:
        current_user: The authenticated and active user from the database.
        db: Database session for permission checks.
        request: The incoming HTTP request used to extract the tenant context.

    Raises:
        HTTPException: If the user does not have sufficient privileges.

    Returns:
        The ``User`` instance when the user has administrative access.
    """
    # Superusers always pass
    if current_user.is_superuser:
        return current_user

    # Paid tiers are considered admins by default
    if current_user.tier in ["pro", "enterprise", "premium"]:
        return current_user

    # Determine the organization context from the request, if available.
    org_id = None
    if request is not None:
        try:
            tenant_context = get_tenant_context(request)
            org_id = tenant_context.organization_id or current_user.default_organization_id
        except Exception:
            # If tenant context is not set, fall back to user's default org
            org_id = current_user.default_organization_id
    else:
        org_id = current_user.default_organization_id

    # Use the PermissionChecker to inspect the user's role in the organization
    checker = PermissionChecker(db)
    try:
        role_name = checker.get_user_role_in_organization(current_user, org_id) if org_id else None
        if role_name in ["org_owner", "admin"]:
            return current_user
    except Exception:
        # On any error, deny access below
        pass

    # If none of the above conditions are met, deny access
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="Admin access required",
    )


async def get_optional_user(
    db: Session = Depends(get_db),
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(HTTPBearer(auto_error=False)),
) -> Optional[User]:
    """
    Optionally retrieve the current user if a valid JWT is provided; otherwise return None.

    This can be used on routes that allow both authenticated and anonymous access.
    """
    if not credentials:
        return None
    try:
        token = credentials.credentials
        current_user = await get_current_user(db, token)
        return get_current_active_user(current_user, db)
    except HTTPException:
        # Return None if authentication fails; do not propagate the error
        return None