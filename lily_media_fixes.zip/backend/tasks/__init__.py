"""Task package initialization.

This package contains Celery task definitions and scheduling configuration for
the AI social media platform. It mirrors the upstream project structure so
that Celery workers can discover tasks via the ``include`` list in
``celery_app.py``.
"""

__all__ = []